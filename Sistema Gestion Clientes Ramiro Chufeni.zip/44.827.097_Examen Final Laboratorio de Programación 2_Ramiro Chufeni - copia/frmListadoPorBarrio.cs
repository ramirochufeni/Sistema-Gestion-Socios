﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _44._827._097_Examen_Final_Laboratorio_de_Programación_2_Ramiro_Chufeni
{
    public partial class frmListadoPorBarrio : Form
    {
        private Int32 idBarrioSeleccionado = 0;
        private string nombreBarrioSeleccionado = "";
        public frmListadoPorBarrio()
        {
            InitializeComponent();
        }

        private void frmListadoPorBarrio_Load(object sender, EventArgs e)
        {
            clsBarrio barrio = new clsBarrio();
            barrio.CargarCombo(cmbBarrio);

        }
        private void btnListar_Click(object sender, EventArgs e)
        {
            if (cmbBarrio.SelectedValue is Int32 idBarrio)
            {
                clsSocio socio = new clsSocio();
                socio.ListarPorBarrio(dgvGrilla, idBarrio);
                lblCantidad.Text = socio.Cantidad.ToString();
                lblTotal.Text = socio.TotalDeuda.ToString("N2");
            }
            else
            {
                MessageBox.Show("Debe seleccionar un barrio válido.");
            }
        }
        private void btnExportar_Click(object sender, EventArgs e)
        {
            if (cmbBarrio.SelectedIndex == -1)
            {
                MessageBox.Show("Debe seleccionar un barrio.");
                return;
            }

            idBarrioSeleccionado = Convert.ToInt32(cmbBarrio.SelectedValue);
            nombreBarrioSeleccionado = cmbBarrio.Text;

            clsSocio socio = new clsSocio();
            socio.ReporteSociosDeUnBarrio(idBarrioSeleccionado, nombreBarrioSeleccionado);

            
        }
        private void btnImprimir_Click(object sender, EventArgs e)
        {
            if (cmbBarrio.SelectedIndex == -1)
            {
                MessageBox.Show("Debe seleccionar un barrio.");
                return;
            }

            idBarrioSeleccionado = Convert.ToInt32(cmbBarrio.SelectedValue);
            nombreBarrioSeleccionado = cmbBarrio.Text;

            prtVentana.Document = prtDocumento;
            if (prtVentana.ShowDialog() == DialogResult.OK)
            {
                prtDocumento.Print();
            }
            MessageBox.Show("Listado impreso exitosamente");
        }

        private void prtDocumento_PrintPage(object sender, PrintPageEventArgs e)
        {
            clsSocio socio = new clsSocio();
            socio.ImprimirSociosPorBarrio(e, idBarrioSeleccionado, nombreBarrioSeleccionado);
        }
    }
}
