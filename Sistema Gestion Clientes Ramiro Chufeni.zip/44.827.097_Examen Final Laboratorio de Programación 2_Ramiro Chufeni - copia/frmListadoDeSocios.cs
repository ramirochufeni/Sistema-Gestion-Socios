﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace _44._827._097_Examen_Final_Laboratorio_de_Programación_2_Ramiro_Chufeni
{
    public partial class frmListadoDeSocios : Form
    {
        clsSocio socio = new clsSocio();
        public frmListadoDeSocios()
        {
            InitializeComponent();
        }

        private void frmListadoDeSocios_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
           
            dgvSocios.Rows.Clear();

            

            socio.ListarSocios(dgvSocios);

            lblTotalDeuda.Text = socio.TotalDeuda.ToString("N2");
            lblPromedio.Text = socio.PromedioDeuda.ToString("N2");
            lblMayor.Text = socio.MayorDeuda.ToString("N2");
            lblMenor.Text = socio.MenorDeuda.ToString("N2");
        }

        private void btnImprimir_Click(object sender, EventArgs e)
        {
            if (prtVentana.ShowDialog() == DialogResult.OK)
            {
                prtDocumento.PrinterSettings = prtVentana.PrinterSettings;
                prtDocumento.Print();
            }
            MessageBox.Show("Listado impreso exitosamente");
        }
       
        private void btnExportar_Click(object sender, EventArgs e)
        {
            socio.ReporteSocios();
        }

        private void prtDocumento_PrintPage(object sender, PrintPageEventArgs e)
        {
            clsSocio socio = new clsSocio();
            socio.Imprimir(e);
        }
    }
}

