﻿namespace _44._827._097_Examen_Final_Laboratorio_de_Programación_2_Ramiro_Chufeni
{
    partial class frmPrincipal
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.sistemaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.acercaDelDesarrolladorDelSistemaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.salirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sociosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.agregarNuevosSociosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.buscarSocioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.consultaDeUnSocioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripSeparator();
            this.listadoDeTodosLosSociosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listadoDeSociosDeudoresToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listadoDeSociosDeUnaActividadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listadoDeSociosDeUnBarrioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sistemaToolStripMenuItem,
            this.sociosToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1372, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // sistemaToolStripMenuItem
            // 
            this.sistemaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.acercaDelDesarrolladorDelSistemaToolStripMenuItem,
            this.toolStripMenuItem1,
            this.salirToolStripMenuItem});
            this.sistemaToolStripMenuItem.Name = "sistemaToolStripMenuItem";
            this.sistemaToolStripMenuItem.Size = new System.Drawing.Size(75, 24);
            this.sistemaToolStripMenuItem.Text = "Sistema";
            // 
            // acercaDelDesarrolladorDelSistemaToolStripMenuItem
            // 
            this.acercaDelDesarrolladorDelSistemaToolStripMenuItem.Name = "acercaDelDesarrolladorDelSistemaToolStripMenuItem";
            this.acercaDelDesarrolladorDelSistemaToolStripMenuItem.Size = new System.Drawing.Size(343, 26);
            this.acercaDelDesarrolladorDelSistemaToolStripMenuItem.Text = "Acerca del desarrollador del sistema...";
            this.acercaDelDesarrolladorDelSistemaToolStripMenuItem.Click += new System.EventHandler(this.acercaDelDesarrolladorDelSistemaToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(340, 6);
            // 
            // salirToolStripMenuItem
            // 
            this.salirToolStripMenuItem.Name = "salirToolStripMenuItem";
            this.salirToolStripMenuItem.Size = new System.Drawing.Size(343, 26);
            this.salirToolStripMenuItem.Text = "Salir";
            this.salirToolStripMenuItem.Click += new System.EventHandler(this.salirToolStripMenuItem_Click);
            // 
            // sociosToolStripMenuItem
            // 
            this.sociosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.agregarNuevosSociosToolStripMenuItem,
            this.toolStripMenuItem2,
            this.buscarSocioToolStripMenuItem,
            this.consultaDeUnSocioToolStripMenuItem,
            this.toolStripMenuItem3,
            this.listadoDeTodosLosSociosToolStripMenuItem,
            this.listadoDeSociosDeudoresToolStripMenuItem,
            this.listadoDeSociosDeUnaActividadToolStripMenuItem,
            this.listadoDeSociosDeUnBarrioToolStripMenuItem});
            this.sociosToolStripMenuItem.Name = "sociosToolStripMenuItem";
            this.sociosToolStripMenuItem.Size = new System.Drawing.Size(66, 24);
            this.sociosToolStripMenuItem.Text = "Socios";
            // 
            // agregarNuevosSociosToolStripMenuItem
            // 
            this.agregarNuevosSociosToolStripMenuItem.Name = "agregarNuevosSociosToolStripMenuItem";
            this.agregarNuevosSociosToolStripMenuItem.Size = new System.Drawing.Size(329, 26);
            this.agregarNuevosSociosToolStripMenuItem.Text = "Agregar nuevos socios...";
            this.agregarNuevosSociosToolStripMenuItem.Click += new System.EventHandler(this.agregarNuevosSociosToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(326, 6);
            // 
            // buscarSocioToolStripMenuItem
            // 
            this.buscarSocioToolStripMenuItem.Name = "buscarSocioToolStripMenuItem";
            this.buscarSocioToolStripMenuItem.Size = new System.Drawing.Size(329, 26);
            this.buscarSocioToolStripMenuItem.Text = "Buscar socio...";
            this.buscarSocioToolStripMenuItem.Click += new System.EventHandler(this.buscarSocioToolStripMenuItem_Click);
            // 
            // consultaDeUnSocioToolStripMenuItem
            // 
            this.consultaDeUnSocioToolStripMenuItem.Name = "consultaDeUnSocioToolStripMenuItem";
            this.consultaDeUnSocioToolStripMenuItem.Size = new System.Drawing.Size(329, 26);
            this.consultaDeUnSocioToolStripMenuItem.Text = "Consulta de un socio...";
            this.consultaDeUnSocioToolStripMenuItem.Click += new System.EventHandler(this.consultaDeUnSocioToolStripMenuItem_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(326, 6);
            // 
            // listadoDeTodosLosSociosToolStripMenuItem
            // 
            this.listadoDeTodosLosSociosToolStripMenuItem.Name = "listadoDeTodosLosSociosToolStripMenuItem";
            this.listadoDeTodosLosSociosToolStripMenuItem.Size = new System.Drawing.Size(329, 26);
            this.listadoDeTodosLosSociosToolStripMenuItem.Text = "Listado de todos los socios...";
            this.listadoDeTodosLosSociosToolStripMenuItem.Click += new System.EventHandler(this.listadoDeTodosLosSociosToolStripMenuItem_Click);
            // 
            // listadoDeSociosDeudoresToolStripMenuItem
            // 
            this.listadoDeSociosDeudoresToolStripMenuItem.Name = "listadoDeSociosDeudoresToolStripMenuItem";
            this.listadoDeSociosDeudoresToolStripMenuItem.Size = new System.Drawing.Size(329, 26);
            this.listadoDeSociosDeudoresToolStripMenuItem.Text = "Listado de socios deudores...";
            this.listadoDeSociosDeudoresToolStripMenuItem.Click += new System.EventHandler(this.listadoDeSociosDeudoresToolStripMenuItem_Click);
            // 
            // listadoDeSociosDeUnaActividadToolStripMenuItem
            // 
            this.listadoDeSociosDeUnaActividadToolStripMenuItem.Name = "listadoDeSociosDeUnaActividadToolStripMenuItem";
            this.listadoDeSociosDeUnaActividadToolStripMenuItem.Size = new System.Drawing.Size(329, 26);
            this.listadoDeSociosDeUnaActividadToolStripMenuItem.Text = "Listado de socios de una actividad...";
            this.listadoDeSociosDeUnaActividadToolStripMenuItem.Click += new System.EventHandler(this.listadoDeSociosDeUnaActividadToolStripMenuItem_Click);
            // 
            // listadoDeSociosDeUnBarrioToolStripMenuItem
            // 
            this.listadoDeSociosDeUnBarrioToolStripMenuItem.Name = "listadoDeSociosDeUnBarrioToolStripMenuItem";
            this.listadoDeSociosDeUnBarrioToolStripMenuItem.Size = new System.Drawing.Size(329, 26);
            this.listadoDeSociosDeUnBarrioToolStripMenuItem.Text = "Listado de socios de un barrio...";
            this.listadoDeSociosDeUnBarrioToolStripMenuItem.Click += new System.EventHandler(this.listadoDeSociosDeUnBarrioToolStripMenuItem_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::_44._827._097_Examen_Final_Laboratorio_de_Programación_2_Ramiro_Chufeni.Properties.Resources.logg;
            this.pictureBox1.Location = new System.Drawing.Point(123, 53);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1727, 990);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // frmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PowderBlue;
            this.ClientSize = new System.Drawing.Size(1372, 798);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmPrincipal";
            this.Text = "frmPrincipal";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmPrincipal_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem sistemaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem acercaDelDesarrolladorDelSistemaToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem salirToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sociosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem agregarNuevosSociosToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem buscarSocioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem consultaDeUnSocioToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem listadoDeTodosLosSociosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listadoDeSociosDeudoresToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listadoDeSociosDeUnaActividadToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listadoDeSociosDeUnBarrioToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

