﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _44._827._097_Examen_Final_Laboratorio_de_Programación_2_Ramiro_Chufeni
{
    public partial class frmBuscarSocio : Form
    {
        clsSocio socio = new clsSocio();
        public frmBuscarSocio()
        {
            InitializeComponent();
        }

        private void frmBuscarSocio_Load(object sender, EventArgs e)
        {
            clsBarrio b = new clsBarrio();
            clsActividad a = new clsActividad();
            b.CargarCombo(cmbBarrio);
            a.CargarCombo(cmbActividad);

            btnBuscar.Enabled = false;
            btnModificar.Enabled = false;
            btnEliminar.Enabled = false;

            txtNombre.Enabled = false;
            txtDireccion.Enabled = false;
            txtDeuda.Enabled = false;
            cmbBarrio.Enabled = false;
            cmbActividad.Enabled = false;

            txtDNI.TextChanged += txtDNI_TextChanged;
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            if (txtDNI.Text == "")
            {
                MessageBox.Show("Ingrese un DNI para buscar.");
                return;
            }

            socio.Buscar(Convert.ToInt32(txtDNI.Text));

            if (socio.IdSocio != 0)
            {
                txtNombre.Text = socio.Nombre;
                txtDireccion.Text = socio.Direccion;
                txtDeuda.Text = socio.Deuda.ToString();
                cmbBarrio.SelectedValue = socio.IdBarrio;
                cmbActividad.SelectedValue = socio.IdActividad;
                txtNombre.Enabled = true;
                txtDireccion.Enabled = true;
                txtDeuda.Enabled = true;
                cmbBarrio.Enabled = true;
                cmbActividad.Enabled = true;

                btnModificar.Enabled = true;
                btnEliminar.Enabled = true;
            }
            else
            {
                MessageBox.Show("Socio no encontrado.");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                socio.Nombre = txtNombre.Text;
                socio.Direccion = txtDireccion.Text;
                socio.Deuda = Convert.ToDecimal(txtDeuda.Text);
                socio.IdBarrio = Convert.ToInt32(cmbBarrio.SelectedValue);
                socio.IdActividad = Convert.ToInt32(cmbActividad.SelectedValue);

                socio.Modificar(Convert.ToInt32(txtDNI.Text));

                MessageBox.Show("Datos modificados correctamente.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al modificar: " + ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DialogResult r = MessageBox.Show("¿Seguro que desea eliminar este socio?", "Confirmar", MessageBoxButtons.YesNo);

            if (r == DialogResult.Yes)
            {
                try
                {
                    socio.Eliminar(Convert.ToInt32(txtDNI.Text));
                    MessageBox.Show("Socio eliminado correctamente.");
                    Limpiar();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al eliminar: " + ex.Message);
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtDNI_TextChanged(object sender, EventArgs e)
        {
            btnBuscar.Enabled = txtDNI.Text.Trim() != "";
        }

        private void Limpiar()
        {
            txtDNI.Clear();
            txtNombre.Clear();
            txtDireccion.Clear();
            txtDeuda.Clear();
            cmbBarrio.SelectedIndex = -1;
            cmbActividad.SelectedIndex = -1;

            txtNombre.Enabled = false;
            txtDireccion.Enabled = false;
            txtDeuda.Enabled = false;
            cmbBarrio.Enabled = false;
            cmbActividad.Enabled = false;

            btnModificar.Enabled = false;
            btnEliminar.Enabled = false;
            btnBuscar.Enabled = false;

            txtDNI.Focus();
        }
    }
}
