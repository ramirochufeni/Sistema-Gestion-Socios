﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _44._827._097_Examen_Final_Laboratorio_de_Programación_2_Ramiro_Chufeni
{
    public partial class frmListadoPorActividad : Form
    {
        public frmListadoPorActividad()
        {
            InitializeComponent();
        }

        private void frmListadoPorActividad_Load(object sender, EventArgs e)
        {
            clsActividad act = new clsActividad();
            act.CargarCombo(cmbActividad);
        }

        private void btnListar_Click(object sender, EventArgs e)
        {
            if (cmbActividad.SelectedIndex != -1)
            {
               

                Int32 idActividad = Convert.ToInt32(cmbActividad.SelectedValue);
                clsSocio socio = new clsSocio();
                socio.ListarPorActividad(dgvGrilla, idActividad);
                lblMayor.Text = socio.MayorDeuda.ToString("N2");
                lblMenor.Text = socio.MenorDeuda.ToString("N2");
                lblTotal.Text = socio.TotalDeuda.ToString("N2");
                lblPromedio.Text = socio.PromedioDeuda.ToString("N2");
            }
            else
            {
                MessageBox.Show("Seleccione una actividad.");
            }
        }

        private void btnExportar_Click(object sender, EventArgs e)
        {
            if (cmbActividad.SelectedIndex != -1)
            {
                Int32 idActividad = Convert.ToInt32(cmbActividad.SelectedValue);
                string nombreActividad = cmbActividad.Text;

                clsSocio socio = new clsSocio();
                socio.ReporteSociosPorActividad(idActividad, nombreActividad);
            }
            else
            {
                MessageBox.Show("Seleccione una actividad.");
            }
        }

        private void btnImprimir_Click(object sender, EventArgs e)
        {
            if (cmbActividad.SelectedIndex != -1)
            {
                Int32 idActividad = Convert.ToInt32(cmbActividad.SelectedValue);
                clsSocio socio = new clsSocio();
                prtVentana.Document = prtDocumento;
                if (prtVentana.ShowDialog() == DialogResult.OK)
                {
                    prtDocumento.Print();
                }
                MessageBox.Show("Listado impreso exitosamente");
            }
            else
            {
                MessageBox.Show("Seleccione una actividad.");
            }
        }

        private void prtDocumento_PrintPage(object sender, PrintPageEventArgs e)
        {
            clsSocio socio = new clsSocio();
            Int32 idActividad = Convert.ToInt32(cmbActividad.SelectedValue);
            socio.ImprimirListadoPorActividad(e, idActividad);
        }
    }
    }

