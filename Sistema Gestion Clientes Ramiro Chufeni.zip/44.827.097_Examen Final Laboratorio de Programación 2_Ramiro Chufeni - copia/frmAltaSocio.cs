﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _44._827._097_Examen_Final_Laboratorio_de_Programación_2_Ramiro_Chufeni
{
    public partial class frmAltaSocio : Form
    {
        public frmAltaSocio()
        {
            InitializeComponent();
        }

        private void frmAltaSocio_Load(object sender, EventArgs e)
        {
            clsBarrio b = new clsBarrio();
            clsActividad a = new clsActividad();

            b.CargarCombo(cmbBarrio);
            a.CargarCombo(cmbActividad);
            
            btnAgregar.Enabled = false;
            txtIdSocio.TextChanged += ValidarCampos;
            txtNombre.TextChanged += ValidarCampos;
            txtDireccion.TextChanged += ValidarCampos;
            txtDeuda.TextChanged += ValidarCampos;
            cmbBarrio.SelectedIndexChanged += ValidarCampos;
            cmbActividad.SelectedIndexChanged += ValidarCampos;
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            if (txtIdSocio.Text == "" || txtNombre.Text == "" || txtDireccion.Text == "" || cmbBarrio.SelectedIndex == -1 || cmbActividad.SelectedIndex == -1 || txtDeuda.Text == "")
            {
                MessageBox.Show("Por favor complete todos los campos.");
                return;
            }

            clsSocio socio = new clsSocio();

            try
            {
                socio.IdSocio = Convert.ToInt32(txtIdSocio.Text);
                socio.Nombre = txtNombre.Text;
                socio.Direccion = txtDireccion.Text;
                socio.IdBarrio = Convert.ToInt32(cmbBarrio.SelectedValue);
                socio.IdActividad = Convert.ToInt32(cmbActividad.SelectedValue);
                socio.Deuda = Convert.ToDecimal(txtDeuda.Text);

                socio.Agregar();

                MessageBox.Show("Socio agregado correctamente.");
                Limpiar();
            }
            catch (FormatException)
            {
                MessageBox.Show("Error de formato. Verifique los datos ingresados.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error inesperado: " + ex.Message);
            }
        }

        private void ValidarCampos(object sender, EventArgs e)
        {
            bool camposCompletos =
                !string.IsNullOrWhiteSpace(txtIdSocio.Text) &&
                !string.IsNullOrWhiteSpace(txtNombre.Text) &&
                !string.IsNullOrWhiteSpace(txtDireccion.Text) &&
                !string.IsNullOrWhiteSpace(txtDeuda.Text) &&
                cmbBarrio.SelectedIndex != -1 &&
                cmbActividad.SelectedIndex != -1;

            btnAgregar.Enabled = camposCompletos;
        }
        private void Limpiar()
        {
            txtIdSocio.Clear();
            txtNombre.Clear();
            txtDireccion.Clear();
            txtDeuda.Clear();
            cmbBarrio.SelectedIndex = -1;
            cmbActividad.SelectedIndex = -1;
            txtIdSocio.Focus();

            btnAgregar.Enabled = false;
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
           
            
                this.Close();
           
        }
    }
}
