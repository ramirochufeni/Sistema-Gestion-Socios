﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;


namespace _44._827._097_Examen_Final_Laboratorio_de_Programación_2_Ramiro_Chufeni
{
    public partial class frmConsultaSocio : Form
    {
        public frmConsultaSocio()
        {
            InitializeComponent();
        }

        private void frmConsultaSocio_Load(object sender, EventArgs e)
        {
            clsSocio socio = new clsSocio();
            socio.CargarCombo(cmbSocios);
        }

        private void cmbSocios_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                Int32 codigo = Convert.ToInt32(cmbSocios.SelectedValue);

                clsSocio socio = new clsSocio();
                socio.Buscar(codigo);

                if (socio.IdSocio != 0)
                {
                    lblValorDNI.Text = socio.IdSocio.ToString();
                    lblValorDireccion.Text = socio.Direccion;

                    clsBarrio b = new clsBarrio();
                    lblValorBarrio.Text = b.Buscar(socio.IdBarrio);

                    clsActividad a = new clsActividad();
                    lblValorActividad.Text = a.Buscar(socio.IdActividad);

                    lblValorDeuda.Text = socio.Deuda.ToString("N2");
                }
                else
                {
                    MessageBox.Show("Socio no encontrado.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al mostrar datos: " + ex.Message);
            }
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
