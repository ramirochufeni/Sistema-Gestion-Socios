﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.IO;
using System.Drawing.Printing;
using System.Drawing;

namespace _44._827._097_Examen_Final_Laboratorio_de_Programación_2_Ramiro_Chufeni
{
    internal class clsSocio
    {
        private OleDbConnection conexion = new OleDbConnection();
        private OleDbCommand comando = new OleDbCommand();
        private OleDbDataAdapter adaptador = new OleDbDataAdapter();
        private string CadenaConexion = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=BD_Clientes.mdb";
        private string Tabla = "Socio";

        private Int32 idSocio;
        private string nombre;
        private string direccion;
        private Int32 idBarrio;
        private Int32 idActividad;
        private Decimal deuda;
        private Int32 cantidad;
        private Decimal promedio;
        private Decimal mayor;
        private Decimal menor;
        


        public decimal TotalDeuda
        {
            get { return deuda; }
        }

        public decimal MayorDeuda
        {
            get { return mayor; }
            set { mayor = value; }
        }

        public decimal MenorDeuda
        {
            get { return menor; }
            set { menor = value; }
        }

        public decimal PromedioDeuda
        {
            get { return promedio; }
            set { promedio = value; }
        }

        public Int32 Cantidad
        {
            get { return cantidad; }
            set { cantidad = value; }
        }

        public Int32 IdSocio
        {
            get { return idSocio; }
            set { idSocio = value; }
        }

        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }

        public string Direccion
        {
            get { return direccion; }
            set { direccion = value; }
        }

        public Int32 IdBarrio
        {
            get { return idBarrio; }
            set { idBarrio = value; }
        }

        public Int32 IdActividad
        {
            get { return idActividad; }
            set { idActividad = value; }
        }

        public decimal Deuda
        {
            get { return deuda; }
            set { deuda = value; }
        }

        public void Agregar()
        {
            try
            {
                conexion.ConnectionString = CadenaConexion;
                conexion.Open();

                comando.Connection = conexion;
                comando.CommandType = CommandType.TableDirect;
                comando.CommandText = Tabla;

                adaptador = new OleDbDataAdapter(comando);
                DataSet DS = new DataSet();
                adaptador.Fill(DS, Tabla);

                DataTable tabla = DS.Tables[Tabla];
                DataRow fila = tabla.NewRow();

                fila["IdSocio"] = idSocio;
                fila["Nombre"] = nombre;
                fila["Direccion"] = direccion;
                fila["idBarrio"] = idBarrio;
                fila["idActividad"] = idActividad;
                fila["Deuda"] = deuda;

                tabla.Rows.Add(fila);

                OleDbCommandBuilder conciliador = new OleDbCommandBuilder(adaptador);
                adaptador.Update(DS, Tabla);

                conexion.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show("Error al agregar socio: " + e.Message);
            }
        }
        public void Buscar(Int32 codigo)
        {
            try
            {
                conexion.ConnectionString = CadenaConexion;
                conexion.Open();
                comando.Connection = conexion;
                comando.CommandType = CommandType.TableDirect;
                comando.CommandText = Tabla;

                OleDbDataReader dr = comando.ExecuteReader();
                idSocio = 0;

                while (dr.Read())
                {
                    if (dr.GetInt32(0) == codigo)
                    {
                        idSocio = dr.GetInt32(0);
                        nombre = dr.GetString(1);
                        direccion = dr.GetString(2);
                        idBarrio = dr.GetInt32(3);
                        idActividad = dr.GetInt32(4);
                        deuda = dr.GetDecimal(5);
                        break;
                    }
                }

                conexion.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al buscar socio: " + ex.Message);
            }
        }
        public void Modificar(Int32 codigo)
        {
            try
            {
                string sql = "";
                sql = "UPDATE Socio SET ";
                sql += "Nombre = '" + nombre + "'";
                sql += ", Direccion = '" + direccion + "'";
                sql += ", idBarrio = " + idBarrio.ToString();
                sql += ", idActividad = " + idActividad.ToString();
                sql += ", Deuda = " + deuda.ToString().Replace(',', '.');
                sql += " WHERE IdSocio = " + codigo.ToString();

                conexion.ConnectionString = CadenaConexion;
                conexion.Open();
                comando.Connection = conexion;
                comando.CommandType = CommandType.Text;
                comando.CommandText = sql;
                comando.ExecuteNonQuery();
                conexion.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show("Error al modificar socio: " + e.Message);
            }
        }
        public void Eliminar(Int32 codigo)
        {
            try
            {
                string sql = "DELETE FROM Socio WHERE IdSocio = " + codigo.ToString();

                conexion.ConnectionString = CadenaConexion;
                conexion.Open();
                comando.Connection = conexion;
                comando.CommandType = CommandType.Text;
                comando.CommandText = sql;
                comando.ExecuteNonQuery();
                conexion.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show("Error al eliminar socio: " + e.Message);
            }
        }
        public void ListarSocios(DataGridView Grilla)
        {
            try
            {
                conexion.ConnectionString = CadenaConexion;
                conexion.Open();
                comando.Connection = conexion;
                comando.CommandType = CommandType.TableDirect;
                comando.CommandText = Tabla;

                OleDbDataReader DR = comando.ExecuteReader();
                Grilla.Rows.Clear();

                cantidad = 0;
                deuda = 0;
                mayor = 0;
                menor = 0;

                clsBarrio barrio = new clsBarrio();
                clsActividad actividad = new clsActividad();

                if (DR.HasRows)
                {
                    while (DR.Read())
                    {
                        Int32 id = DR.GetInt32(0);
                        string nombre = DR.GetString(1);
                        string direccion = DR.GetString(2);
                        Int32 idBarrio = DR.GetInt32(3);
                        Int32 idActividad = DR.GetInt32(4);
                        decimal deu = DR.GetDecimal(5);

                        string nomBarrio = barrio.Buscar(idBarrio);
                        string nomActividad = actividad.Buscar(idActividad);

                        
         
                        Grilla.Rows.Add(id, nombre, nomActividad, nomBarrio, deu.ToString("N2"));

                        if (cantidad == 0)
                            mayor = menor = deu;
                        else
                        {
                            if (deu > mayor) mayor = deu;
                            if (deu < menor) menor = deu;
                        }

                        deuda += deu;
                        cantidad++;
                    }
                }

                conexion.Close();

                if (cantidad > 0)
                    promedio = deuda / cantidad;
                else
                    promedio = 0;
            }
            catch (Exception e)
            {
                MessageBox.Show("Error al listar socios: " + e.Message);
            }
        }

        public void CargarCombo(System.Windows.Forms.ComboBox combo)
        {
            try
            {
                conexion.ConnectionString = CadenaConexion;
                conexion.Open();

                comando.Connection = conexion;
                comando.CommandType = CommandType.Text;
                comando.CommandText = "SELECT IdSocio, Nombre FROM Socio";

                OleDbDataReader dr = comando.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(dr);

                combo.DisplayMember = "Nombre";
                combo.ValueMember = "IdSocio";
                combo.DataSource = dt;

                conexion.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar combo: " + ex.Message);
            }
        }


        public void ReporteSocios()
        {
            try
            {
                conexion.ConnectionString = CadenaConexion;
                conexion.Open();
                comando.Connection = conexion;
                comando.CommandType = CommandType.TableDirect;
                comando.CommandText = Tabla;

                OleDbDataReader DR = comando.ExecuteReader();
                StreamWriter AD = new StreamWriter("ReporteSocios.csv", false, Encoding.UTF8);

                AD.WriteLine("Listado de socios\n");
                AD.WriteLine("DNI;Nombre;Dirección;Barrio;Actividad;Deuda");

                clsBarrio barrio = new clsBarrio();
                clsActividad actividad = new clsActividad();

                cantidad = 0;
                deuda = 0;
                mayor = 0;
                menor = 0;

                if (DR.HasRows)
                {
                    while (DR.Read())
                    {
                        int id = DR.GetInt32(0);
                        string nombre = DR.GetString(1);
                        string direccion = DR.GetString(2);
                        int idBarrio = DR.GetInt32(3);
                        int idActividad = DR.GetInt32(4);
                        decimal deu = DR.GetDecimal(5);

                        string nomBarrio = barrio.Buscar(idBarrio);
                        string nomActividad = actividad.Buscar(idActividad);

                        AD.Write(id);
                        AD.Write(";");
                        AD.Write(nombre);
                        AD.Write(";");
                        AD.Write(direccion);
                        AD.Write(";");
                        AD.Write(nomBarrio);
                        AD.Write(";");
                        AD.Write(nomActividad);
                        AD.Write(";");
                        AD.WriteLine(deu.ToString("N2"));

                        if (cantidad == 0)
                        {
                            mayor = menor = deu;
                        }
                        else
                        {
                            if (deu > mayor) mayor = deu;
                            if (deu < menor) menor = deu;
                        }

                        deuda += deu;
                        cantidad++;
                    }

                    AD.WriteLine();
                    AD.Write("Cantidad de socios: ; ; ; ; ;");
                    AD.WriteLine(cantidad);
                    AD.Write("Deuda total: ; ; ; ; ;");
                    AD.WriteLine(deuda.ToString("N2"));
                    decimal promedio = cantidad > 0 ? deuda / cantidad : 0;
                    AD.Write("Promedio de deuda: ; ; ; ; ;");
                    AD.WriteLine(promedio.ToString("N2"));
                }

                AD.Close();
                conexion.Close();

                MessageBox.Show("Reporte generado correctamente");
            }
            catch (Exception e)
            {
                MessageBox.Show("Error al generar reporte: " + e.Message);
            }
        }
        public void Imprimir(PrintPageEventArgs reporte)
        {
            try
            {
                Font LetraTitulo1 = new Font("Arial", 20);
                Font LetraTitulo2 = new Font("Arial", 12);
                Font LetraTexto = new Font("Arial", 8);
                Int32 f = 180;

                reporte.Graphics.DrawString("Listado de Socios", LetraTitulo1, Brushes.Red, 100, 100);
                reporte.Graphics.DrawString("Código", LetraTitulo2, Brushes.Blue, 100, 150);
                reporte.Graphics.DrawString("Nombre del Socio", LetraTitulo2, Brushes.Blue, 170, 150);

                conexion.ConnectionString = CadenaConexion;
                conexion.Open();
                comando.Connection = conexion;
                comando.CommandType = CommandType.TableDirect;
                comando.CommandText = Tabla;

                DataSet DS = new DataSet();
                adaptador = new OleDbDataAdapter(comando);
                adaptador.Fill(DS, Tabla);

                if (DS.Tables[Tabla].Rows.Count > 0)
                {
                    foreach (DataRow fila in DS.Tables[Tabla].Rows)
                    {
                        reporte.Graphics.DrawString(fila["IdSocio"].ToString(), LetraTexto, Brushes.Black, 100, f);
                        reporte.Graphics.DrawString(fila["Nombre"].ToString(), LetraTexto, Brushes.Black, 150, f);
                        f = f + 11;
                    }
                }

                conexion.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show("Error al imprimir: " + e.Message);
            }
        }
        public void ListarDeudores(DataGridView Grilla)
        {
            try
            {
                conexion.ConnectionString = CadenaConexion;
                conexion.Open();
                comando.Connection = conexion;
                comando.CommandType = CommandType.TableDirect;
                comando.CommandText = Tabla;

                OleDbDataReader DR = comando.ExecuteReader();
                Grilla.Rows.Clear();

                cantidad = 0;
                deuda = 0;
                mayor = 0;
                menor = Decimal.MaxValue;

                if (DR.HasRows)
                {
                    while (DR.Read())
                    {
                        decimal deudaSocio = DR.IsDBNull(5) ? 0 : DR.GetDecimal(5);
                        if (deudaSocio > 0)
                        {
                            int dni = DR.GetInt32(0);
                            string nombre = DR.GetString(1);

                            Grilla.Rows.Add(dni, nombre, deudaSocio.ToString("N2"));

                            cantidad++;
                            deuda += deudaSocio;

                            if (deudaSocio > mayor) mayor = deudaSocio;
                            if (deudaSocio < menor) menor = deudaSocio;
                        }
                    }

                    if (cantidad == 0)
                    {
                        menor = 0;
                    }
                    if (cantidad > 0)
                        promedio = deuda / cantidad;
                    else
                        promedio = 0;
                }

                conexion.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al listar deudores: " + ex.Message);
            }
        }
        public void ReporteDeudores()
        {
            try
            {
                conexion.ConnectionString = CadenaConexion;
                conexion.Open();
                comando.Connection = conexion;
                comando.CommandType = CommandType.TableDirect;
                comando.CommandText = Tabla;

                OleDbDataReader dr = comando.ExecuteReader();
                StreamWriter archivo = new StreamWriter("ReporteDeudores.csv", false, Encoding.UTF8);
                cantidad = 0;
                deuda = 0;
                mayor = 0;
                menor = Decimal.MaxValue;

                archivo.WriteLine("Listado de socios deudores");
                archivo.WriteLine();
                archivo.WriteLine("DNI;Nombre;Deuda");

                while (dr.Read())
                {
                    decimal deudaSocio = dr.IsDBNull(5) ? 0 : dr.GetDecimal(5);
                    if (deudaSocio > 0)
                    {
                        int dni = dr.GetInt32(0);
                        string nombre = dr.GetString(1);

                        archivo.Write(dni);
                        archivo.Write(";");
                        archivo.Write(nombre);
                        archivo.Write(";");
                        archivo.WriteLine(deudaSocio.ToString("N2"));

                        cantidad++;
                        deuda += deudaSocio;

                        if (deudaSocio > mayor) mayor = deudaSocio;
                        if (deudaSocio < menor) menor = deudaSocio;
                    }
                }

                archivo.WriteLine();
                archivo.Write("Total deuda: ; ;");
                archivo.WriteLine(deuda.ToString("N2"));
                archivo.Write("Mayor deuda: ; ;");
                archivo.WriteLine(mayor.ToString("N2"));
                archivo.Write("Menor deuda: ; ;");
                archivo.WriteLine(menor == Decimal.MaxValue ? "0" : menor.ToString("N2"));
                archivo.Write("Promedio deuda: ; ;");
                archivo.WriteLine(cantidad > 0 ? (deuda / cantidad).ToString("N2") : "0");

                archivo.Close();
                conexion.Close();

                MessageBox.Show("Reporte generado correctamente");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al exportar: " + ex.Message);
            }
        }
        public void ImprimirDeudores(PrintPageEventArgs e)
        {
            try
            {
                Font LetraTitulo = new Font("Arial", 16, FontStyle.Bold);
                Font LetraEncabezado = new Font("Arial", 10, FontStyle.Bold);
                Font LetraTexto = new Font("Arial", 9);
                int y = 100;

                e.Graphics.DrawString("Listado de Socios Deudores", LetraTitulo, Brushes.DarkRed, 100, y);
                y += 40;

                e.Graphics.DrawString("DNI", LetraEncabezado, Brushes.Black, 100, y);
                e.Graphics.DrawString("Nombre", LetraEncabezado, Brushes.Black, 200, y);
                e.Graphics.DrawString("Deuda", LetraEncabezado, Brushes.Black, 400, y);
                y += 25;

                conexion.ConnectionString = CadenaConexion;
                conexion.Open();
                comando.Connection = conexion;
                comando.CommandType = CommandType.TableDirect;
                comando.CommandText = Tabla;

                OleDbDataReader dr = comando.ExecuteReader();

                while (dr.Read())
                {
                    decimal deuda = dr.IsDBNull(5) ? 0 : dr.GetDecimal(5);
                    if (deuda > 0)
                    {
                        string dni = dr.IsDBNull(0) ? "" : dr.GetInt32(0).ToString();
                        string nombre = dr.IsDBNull(1) ? "" : dr.GetString(1);

                        e.Graphics.DrawString(dni, LetraTexto, Brushes.Black, 100, y);
                        e.Graphics.DrawString(nombre, LetraTexto, Brushes.Black, 200, y);
                        e.Graphics.DrawString(deuda.ToString("N2"), LetraTexto, Brushes.Black, 400, y);
                        y += 20;
                    }
                }

                conexion.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al imprimir deudores: " + ex.Message);
            }
        }
        public void ExportarDeudores()
        {
            try
            {
                StreamWriter archivo = new StreamWriter("ReporteSociosDeudores.csv", false, Encoding.UTF8);
                archivo.WriteLine("Listado de Socios Deudores");
                archivo.WriteLine();
                archivo.WriteLine("DNI;Nombre;Deuda");

                conexion.ConnectionString = CadenaConexion;
                conexion.Open();
                comando.Connection = conexion;
                comando.CommandType = CommandType.TableDirect;
                comando.CommandText = Tabla;

                OleDbDataReader dr = comando.ExecuteReader();

                cantidad = 0;
                deuda = 0;
                mayor = 0;
                menor = Decimal.MaxValue;

                while (dr.Read())
                {
                    decimal deudaSocio = dr.IsDBNull(5) ? 0 : dr.GetDecimal(5);
                    if (deudaSocio > 0)
                    {
                        int dni = dr.GetInt32(0);
                        string nombre = dr.GetString(1);

                        archivo.Write(dni);
                        archivo.Write(";");
                        archivo.Write(nombre);
                        archivo.Write(";");
                        archivo.WriteLine(deudaSocio.ToString("N2"));

                        cantidad++;
                        deuda += deudaSocio;
                        if (deudaSocio > mayor) mayor = deudaSocio;
                        if (deudaSocio < menor) menor = deudaSocio;
                    }
                }

                if (cantidad == 0)
                {
                    menor = 0;
                }

                archivo.WriteLine();
                archivo.Write("Cantidad de deudores: ;");
                archivo.WriteLine(cantidad);
                archivo.Write("Total deuda: ;");
                archivo.WriteLine(deuda.ToString("N2"));
                archivo.Write("Promedio deuda: ;");
                archivo.WriteLine((cantidad > 0 ? (deuda / cantidad).ToString("N2") : "0,00"));
                archivo.Close();
                conexion.Close();

                MessageBox.Show("Reporte generado correctamente");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al generar el archivo: " + ex.Message);
            }
        }
        public void ListarPorActividad(DataGridView Grilla, Int32 idActividad)
        {
            try
            {
                conexion.ConnectionString = CadenaConexion;
                conexion.Open();
                comando.Connection = conexion;
                comando.CommandType = CommandType.TableDirect;
                comando.CommandText = Tabla;

                OleDbDataReader DR = comando.ExecuteReader();
                Grilla.Rows.Clear();
                cantidad = 0;
                deuda = 0;
                MayorDeuda = Decimal.MinValue;
                MenorDeuda = Decimal.MaxValue;

                if (DR.HasRows)
                {
                    while (DR.Read())
                    {
                        if (!DR.IsDBNull(4) && DR.GetInt32(4) == idActividad) 
                        {
                            Int32 dni = DR.GetInt32(0);
                            string nombre = DR.GetString(1);
                            decimal deu = DR.GetDecimal(5); 

                            Grilla.Rows.Add(dni, nombre, deu.ToString("N2"));
                            cantidad++;
                            deuda += deu;

                            if (deu > MayorDeuda) MayorDeuda = deu;
                            if (deu < MenorDeuda) MenorDeuda = deu;
                        }
                    }
                }

                PromedioDeuda = (cantidad > 0) ? deuda / cantidad : 0;
                conexion.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al listar socios por actividad: " + ex.Message);
            }
        }
        public void ReporteSociosPorActividad(Int32 idActividad, string nombreActividad)
        {
            try
            {
                conexion.ConnectionString = CadenaConexion;
                conexion.Open();

                comando.Connection = conexion;
                comando.CommandType = CommandType.Text;
                comando.CommandText = "SELECT * FROM Socio WHERE idActividad = " + idActividad;

                OleDbDataReader DR = comando.ExecuteReader();
                StreamWriter archivo = new StreamWriter("SociosPorActividad.csv", false, Encoding.UTF8);

                archivo.WriteLine("Listado de socios por actividad");
                archivo.WriteLine("Actividad seleccionada: " + nombreActividad);
                archivo.WriteLine();
                archivo.WriteLine("DNI;Nombre;Deuda");

                cantidad = 0;
                deuda = 0;
                MayorDeuda = Decimal.MinValue;
                MenorDeuda = Decimal.MaxValue;

                while (DR.Read())
                {
                    Int32 dni = DR.GetInt32(0);
                    string nombre = DR.GetString(1);
                    decimal deu = DR.GetDecimal(5);

                    archivo.WriteLine($"{dni};{nombre};{deu.ToString("N2")}");

                    cantidad++;
                    deuda += deu;

                    if (deu > MayorDeuda) MayorDeuda = deu;
                    if (deu < MenorDeuda) MenorDeuda = deu;
                }

                PromedioDeuda = (cantidad > 0) ? deuda / cantidad : 0;

                archivo.WriteLine();
                archivo.WriteLine("Total de deuda:;" + deuda.ToString("N2"));
                archivo.WriteLine("Promedio de deuda:;" + PromedioDeuda.ToString("N2"));
                archivo.WriteLine("Mayor deuda:;" + MayorDeuda.ToString("N2"));
                archivo.WriteLine("Menor deuda:;" + MenorDeuda.ToString("N2"));
                archivo.Close();
                conexion.Close();

                MessageBox.Show("Reporte generado correctamente");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al generar reporte por actividad: " + ex.Message);
            }
        }

        private string ObtenerNombreActividad(Int32 idActividad)
        {
            string nombre = "";
            try
            {
                conexion.ConnectionString = CadenaConexion;
                conexion.Open();
                comando.Connection = conexion;
                comando.CommandType = CommandType.Text;
                comando.CommandText = "SELECT Nombre FROM Actividad WHERE idActividad = " + idActividad;

                object resultado = comando.ExecuteScalar();
                if (resultado != null)
                {
                    nombre = resultado.ToString();
                }
                conexion.Close();
            }
            catch
            {
                nombre = "Desconocida";
            }

            return nombre;
        }

        public void ImprimirListadoPorActividad(PrintPageEventArgs reporte, Int32 idActividad)
        {
            try
            {
                Font LetraTitulo1 = new Font("Arial", 20);
                Font LetraTitulo2 = new Font("Arial", 12);
                Font LetraTexto = new Font("Arial", 8);
                Int32 f = 180;

                reporte.Graphics.DrawString("Listado de Socios por Actividad", LetraTitulo1, Brushes.DarkRed, 100, 100);
                string nombreActividad = ObtenerNombreActividad(idActividad);
                reporte.Graphics.DrawString("Actividad: " + nombreActividad, LetraTitulo2, Brushes.Black, 100, 130);
                reporte.Graphics.DrawString("DNI", LetraTitulo2, Brushes.Blue, 100, 150);
                reporte.Graphics.DrawString("Nombre", LetraTitulo2, Brushes.Blue, 170, 150);
                reporte.Graphics.DrawString("Deuda", LetraTitulo2, Brushes.Blue, 400, 150);

                conexion.ConnectionString = CadenaConexion;
                conexion.Open();

                comando.Connection = conexion;
                comando.CommandType = CommandType.Text;
                comando.CommandText = "SELECT * FROM Socio WHERE idActividad = " + idActividad;

                OleDbDataReader DR = comando.ExecuteReader();

                while (DR.Read())
                {
                    Int32 dni = DR.GetInt32(0);
                    string nombre = DR.GetString(1);
                    decimal deu = DR.GetDecimal(5);

                    reporte.Graphics.DrawString(dni.ToString(), LetraTexto, Brushes.Black, 100, f);
                    reporte.Graphics.DrawString(nombre, LetraTexto, Brushes.Black, 170, f);
                    reporte.Graphics.DrawString(deu.ToString("N2"), LetraTexto, Brushes.Black, 400, f);
                    f += 20;
                }

                conexion.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al imprimir por actividad: " + ex.Message);
            }
        }
        public void ListarPorBarrio(DataGridView grilla, Int32 idBarrio)
        {
            try
            {
                conexion.ConnectionString = CadenaConexion;
                conexion.Open();
                comando.Connection = conexion;
                comando.CommandType = CommandType.TableDirect;
                comando.CommandText = Tabla;

                OleDbDataReader DR = comando.ExecuteReader();

                grilla.Rows.Clear();
                cantidad = 0;
                deuda = 0;

                if (DR.HasRows)
                {
                    while (DR.Read())
                    {
                        if (!DR.IsDBNull(3) && DR.GetInt32(3) == idBarrio)
                        {
                            Int32 dni = DR.GetInt32(0);
                            string nombre = DR.GetString(1);
                            decimal deu = DR.GetDecimal(5); 

                            grilla.Rows.Add(dni, nombre, deu.ToString("N2"));

                            cantidad++;
                            deuda += deu;
                        }
                    }
                }

                conexion.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al listar por barrio: " + ex.Message);
            }
        }
        public void ReporteSociosDeUnBarrio(Int32 IdBarrio, string nombreBarrio)
        {
            try
            {
                Int32 cantidad = 0;
                Decimal total = 0;

                conexion.ConnectionString = CadenaConexion;
                conexion.Open();
                comando.Connection = conexion;
                comando.CommandType = CommandType.TableDirect;
                comando.CommandText = Tabla;

                OleDbDataReader DR = comando.ExecuteReader();

                StreamWriter archivo = new StreamWriter("ReporteSociosPorBarrio.csv", false, Encoding.UTF8);
                archivo.WriteLine("Listado de socios del barrio: " + nombreBarrio);
                archivo.WriteLine();
                archivo.WriteLine("DNI;Nombre;Deuda");

                if (DR.HasRows)
                {
                    while (DR.Read())
                    {
                        if (DR.GetInt32(3) == IdBarrio)
                        {
                            archivo.Write(DR.GetInt32(0));
                            archivo.Write(";");
                            archivo.Write(DR.GetString(1));
                            archivo.Write(";");
                            archivo.WriteLine(DR.GetDecimal(5).ToString("N2"));

                            cantidad++;
                            total += DR.GetDecimal(5);
                        }
                    }
                }

                archivo.WriteLine();
                archivo.Write("Cantidad de socios:;");
                archivo.WriteLine(cantidad);
                archivo.Write("Deuda total:;");
                archivo.WriteLine(total.ToString("N2"));
                archivo.Close();
                conexion.Close();
                MessageBox.Show("Reporte generado correctamente");
            }
            catch (Exception e)
            {
                MessageBox.Show("Error al generar reporte: " + e.Message);
            }
        }
        public void ImprimirSociosPorBarrio(PrintPageEventArgs reporte, Int32 IdBarrio, string nombreBarrio)
        {
            try
            {
                Font LetraTitulo = new Font("Arial", 16);
                Font LetraCabecera = new Font("Arial", 10, FontStyle.Bold);
                Font LetraTexto = new Font("Arial", 9);
                Int32 f = 150;

                reporte.Graphics.DrawString("Listado de Socios del barrio: " + nombreBarrio, LetraTitulo, Brushes.Black, 100, 50);
                reporte.Graphics.DrawString("DNI", LetraCabecera, Brushes.Black, 100, 120);
                reporte.Graphics.DrawString("Nombre", LetraCabecera, Brushes.Black, 200, 120);
                reporte.Graphics.DrawString("Deuda", LetraCabecera, Brushes.Black, 400, 120);

                conexion.ConnectionString = CadenaConexion;
                conexion.Open();
                comando.Connection = conexion;
                comando.CommandType = CommandType.TableDirect;
                comando.CommandText = Tabla;

                OleDbDataReader DR = comando.ExecuteReader();

                if (DR.HasRows)
                {
                    while (DR.Read())
                    {
                        if (DR.GetInt32(3) == IdBarrio)
                        {
                            reporte.Graphics.DrawString(DR.GetInt32(0).ToString(), LetraTexto, Brushes.Black, 100, f);
                            reporte.Graphics.DrawString(DR.GetString(1), LetraTexto, Brushes.Black, 200, f);
                            reporte.Graphics.DrawString(DR.GetDecimal(5).ToString("N2"), LetraTexto, Brushes.Black, 400, f);
                            f += 20;
                        }
                    }
                }

                conexion.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al imprimir: " + ex.Message);
            }
        }
    }
}
