﻿namespace _44._827._097_Examen_Final_Laboratorio_de_Programación_2_Ramiro_Chufeni
{
    partial class frmConsultaSocio
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbSocios = new System.Windows.Forms.ComboBox();
            this.lblValorDNI = new System.Windows.Forms.Label();
            this.lblValorDireccion = new System.Windows.Forms.Label();
            this.lblValorBarrio = new System.Windows.Forms.Label();
            this.lblValorActividad = new System.Windows.Forms.Label();
            this.lblValorDeuda = new System.Windows.Forms.Label();
            this.btnCerrar = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(184, 302);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(69, 20);
            this.label6.TabIndex = 11;
            this.label6.Text = "Deuda:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(161, 259);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(92, 20);
            this.label5.TabIndex = 10;
            this.label5.Text = "Actividad:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(186, 205);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(67, 20);
            this.label4.TabIndex = 9;
            this.label4.Text = "Barrio:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(157, 155);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(96, 20);
            this.label3.TabIndex = 8;
            this.label3.Text = "Dirección:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(206, 108);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 20);
            this.label2.TabIndex = 7;
            this.label2.Text = "DNI:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(69, 64);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(184, 20);
            this.label1.TabIndex = 6;
            this.label1.Text = "Seleccione un socio:";
            // 
            // cmbSocios
            // 
            this.cmbSocios.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSocios.FormattingEnabled = true;
            this.cmbSocios.Location = new System.Drawing.Point(293, 64);
            this.cmbSocios.Name = "cmbSocios";
            this.cmbSocios.Size = new System.Drawing.Size(153, 24);
            this.cmbSocios.TabIndex = 12;
            this.cmbSocios.SelectedIndexChanged += new System.EventHandler(this.cmbSocios_SelectedIndexChanged);
            // 
            // lblValorDNI
            // 
            this.lblValorDNI.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblValorDNI.Location = new System.Drawing.Point(293, 110);
            this.lblValorDNI.Name = "lblValorDNI";
            this.lblValorDNI.Size = new System.Drawing.Size(153, 23);
            this.lblValorDNI.TabIndex = 13;
            // 
            // lblValorDireccion
            // 
            this.lblValorDireccion.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblValorDireccion.Location = new System.Drawing.Point(293, 157);
            this.lblValorDireccion.Name = "lblValorDireccion";
            this.lblValorDireccion.Size = new System.Drawing.Size(153, 23);
            this.lblValorDireccion.TabIndex = 14;
            // 
            // lblValorBarrio
            // 
            this.lblValorBarrio.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblValorBarrio.Location = new System.Drawing.Point(293, 207);
            this.lblValorBarrio.Name = "lblValorBarrio";
            this.lblValorBarrio.Size = new System.Drawing.Size(153, 23);
            this.lblValorBarrio.TabIndex = 15;
            // 
            // lblValorActividad
            // 
            this.lblValorActividad.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblValorActividad.Location = new System.Drawing.Point(293, 256);
            this.lblValorActividad.Name = "lblValorActividad";
            this.lblValorActividad.Size = new System.Drawing.Size(153, 23);
            this.lblValorActividad.TabIndex = 16;
            // 
            // lblValorDeuda
            // 
            this.lblValorDeuda.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblValorDeuda.Location = new System.Drawing.Point(293, 304);
            this.lblValorDeuda.Name = "lblValorDeuda";
            this.lblValorDeuda.Size = new System.Drawing.Size(153, 23);
            this.lblValorDeuda.TabIndex = 17;
            // 
            // btnCerrar
            // 
            this.btnCerrar.Location = new System.Drawing.Point(311, 364);
            this.btnCerrar.Name = "btnCerrar";
            this.btnCerrar.Size = new System.Drawing.Size(108, 42);
            this.btnCerrar.TabIndex = 18;
            this.btnCerrar.Text = "Cerrar";
            this.btnCerrar.UseVisualStyleBackColor = true;
            this.btnCerrar.Click += new System.EventHandler(this.btnCerrar_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(242, 9);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(315, 36);
            this.label7.TabIndex = 19;
            this.label7.Text = "Consulta de un socio";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::_44._827._097_Examen_Final_Laboratorio_de_Programación_2_Ramiro_Chufeni.Properties.Resources.consulta_socio;
            this.pictureBox1.Location = new System.Drawing.Point(532, 110);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(207, 176);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 20;
            this.pictureBox1.TabStop = false;
            // 
            // frmConsultaSocio
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.btnCerrar);
            this.Controls.Add(this.lblValorDeuda);
            this.Controls.Add(this.lblValorActividad);
            this.Controls.Add(this.lblValorBarrio);
            this.Controls.Add(this.lblValorDireccion);
            this.Controls.Add(this.lblValorDNI);
            this.Controls.Add(this.cmbSocios);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "frmConsultaSocio";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmConsultaSocio";
            this.Load += new System.EventHandler(this.frmConsultaSocio_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbSocios;
        private System.Windows.Forms.Label lblValorDNI;
        private System.Windows.Forms.Label lblValorDireccion;
        private System.Windows.Forms.Label lblValorBarrio;
        private System.Windows.Forms.Label lblValorActividad;
        private System.Windows.Forms.Label lblValorDeuda;
        private System.Windows.Forms.Button btnCerrar;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}