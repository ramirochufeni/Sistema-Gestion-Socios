﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _44._827._097_Examen_Final_Laboratorio_de_Programación_2_Ramiro_Chufeni
{
    public partial class frmAcercaDelDesarrollador : Form
    {
        public frmAcercaDelDesarrollador()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void frmAcercaDelDesarrollador_Load(object sender, EventArgs e)
        {

        }
    }
}
