﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;


namespace _44._827._097_Examen_Final_Laboratorio_de_Programación_2_Ramiro_Chufeni
{
    internal class clsBarrio
    {
        private OleDbConnection conexion = new OleDbConnection();
        private OleDbCommand comando = new OleDbCommand();
        private OleDbDataAdapter adaptador = new OleDbDataAdapter();
        private string CadenaConexion = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=BD_Clientes.mdb";
        private string Tabla = "Barrio";

        private Int32 idBarrio;
        private string nombreBarrio;

        public Int32 IdBarrio
        {
            get { return idBarrio; }
            set { idBarrio = value; }
        }

        public string NombreBarrio
        {
            get { return nombreBarrio; }
            set { nombreBarrio = value; }
        }

        public void CargarCombo(ComboBox combo)
        {
            try
            {
                conexion.ConnectionString = CadenaConexion;
                conexion.Open();

                comando.Connection = conexion;
                comando.CommandType = CommandType.Text;
                comando.CommandText = "SELECT idBarrio, Nombre FROM Barrio";

                OleDbDataAdapter da = new OleDbDataAdapter(comando);
                DataTable dt = new DataTable();
                da.Fill(dt);

                combo.DataSource = dt;
                combo.DisplayMember = "Nombre";    
                combo.ValueMember = "idBarrio";     
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar barrios: " + ex.Message);
            }
            finally
            {
                conexion.Close();
            }
        }

        public string Buscar(Int32 id)
        {
            string nombre = "";
            try
            {
                conexion.ConnectionString = CadenaConexion;
                conexion.Open();
                comando.Connection = conexion;
                comando.CommandType = CommandType.TableDirect;
                comando.CommandText = Tabla;

                OleDbDataReader dr = comando.ExecuteReader();

                while (dr.Read())
                {
                    if (dr.GetInt32(0) == id)
                    {
                        nombre = dr.GetString(1);
                        break;
                    }
                }

                conexion.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al buscar barrio: " + ex.Message);
            }

            return nombre;
        }
    }
}
