﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _44._827._097_Examen_Final_Laboratorio_de_Programación_2_Ramiro_Chufeni
{
    public partial class frmListadoDeSociosDeudores : Form
    {
        public frmListadoDeSociosDeudores()
        {
            InitializeComponent();
        }

        private void btnListar_Click(object sender, EventArgs e)
        {
            clsSocio socio = new clsSocio();
            dgvGrilla.Rows.Clear();
            socio.ListarDeudores(dgvGrilla);

            lblTotal.Text = socio.TotalDeuda.ToString("N2");
            lblMayor.Text = socio.MayorDeuda.ToString("N2");
            lblMenor.Text = socio.MenorDeuda.ToString("N2");
            lblPromedio.Text = socio.PromedioDeuda.ToString("N2");
        }

        private void btnExportar_Click(object sender, EventArgs e)
        {
            clsSocio socio = new clsSocio();
            socio.ExportarDeudores();
        }

        private void btnImprimir_Click(object sender, EventArgs e)
        {
            if (prtVentana.ShowDialog() == DialogResult.OK)
            {
                prtDocumento.PrinterSettings = prtVentana.PrinterSettings;
                prtDocumento.Print();
            }
            MessageBox.Show("Listado impreso exitosamente");
        }

        private void prtDocumento_PrintPage(object sender, PrintPageEventArgs e)
        {
            clsSocio socio = new clsSocio();
            socio.ImprimirDeudores(e);
        }

        private void frmListadoDeSociosDeudores_Load(object sender, EventArgs e)
        {

        }
    }
}
